#ifndef __P3_THREADS_H
#define __P3_THREADS_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sys/time.h>
#include <string>
#include <vector>
#include <unistd.h>
#include "types_p3.h"


void *threadfunc(void *parm);




#endif
